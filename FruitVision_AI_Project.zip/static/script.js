
function showPage(pageId, button) {

    document.querySelectorAll(".page")
        .forEach(page => {
            page.classList.remove("active");
        });

    document.getElementById(pageId)
        .classList.add("active");

    document.querySelectorAll(".nav-btn")
        .forEach(btn => {
            btn.classList.remove("active");
        });

    if (button) {
        button.classList.add("active");
    }
}


function openPrediction() {

    showPage(
        "prediction",
        document.querySelectorAll(".nav-btn")[1]
    );
}


function previewPrediction() {

    const input =
        document.getElementById("predictionImage");

    const preview =
        document.getElementById("predictionPreview");

    const content =
        document.getElementById("uploadContent");

    if (input.files && input.files[0]) {

        preview.src =
            URL.createObjectURL(input.files[0]);

        preview.style.display = "block";

        content.style.display = "none";
    }
}


async function predictFruit() {

    const input =
        document.getElementById("predictionImage");

    const result =
        document.getElementById("predictionResult");

    if (!input.files.length) {

        alert("Please upload a fruit image first.");

        return;
    }

    const formData = new FormData();

    formData.append(
        "image",
        input.files[0]
    );

    result.innerHTML = `
        <div class="empty-result">
            <span>⏳</span>
            <h2>Analyzing...</h2>
            <p>AI model is processing your image.</p>
        </div>
    `;

    try {

        const response =
            await fetch(
                "/predict",
                {
                    method: "POST",
                    body: formData
                }
            );

        const data =
            await response.json();

        if (data.error) {
            throw new Error(data.error);
        }

        let top3HTML = "";

        data.top3.forEach(
            (item, index) => {

                top3HTML += `
                    <div style="
                        display:flex;
                        justify-content:space-between;
                        padding:10px 0;
                        border-bottom:1px solid #eee;
                    ">
                        <span>
                            ${index + 1}.
                            ${item.name}
                        </span>

                        <b>
                            ${item.confidence}%
                        </b>
                    </div>
                `;
            }
        );

        result.innerHTML = `

            <p class="small-title">
                PREDICTION RESULT
            </p>

            <div class="prediction-name">
                🍓 ${data.prediction}
            </div>

            <div class="confidence">
                ${data.confidence}% Confidence
            </div>

            <br>

            <h3>Top 3 Predictions</h3>

            ${top3HTML}

        `;

    } catch (error) {

        result.innerHTML = `
            <div class="empty-result">
                <span>❌</span>
                <h2>Prediction Failed</h2>
                <p>${error.message}</p>
            </div>
        `;
    }
}


function previewEnhancement() {

    const input =
        document.getElementById("enhanceImage");

    const preview =
        document.getElementById("originalEnhance");

    if (input.files.length) {

        preview.src =
            URL.createObjectURL(input.files[0]);
    }
}


async function enhanceImage() {

    const input =
        document.getElementById("enhanceImage");

    const method =
        document.getElementById("method").value;

    if (!input.files.length) {

        alert("Please upload an image first.");

        return;
    }

    const formData = new FormData();

    formData.append(
        "image",
        input.files[0]
    );

    formData.append(
        "method",
        method
    );

    const response =
        await fetch(
            "/enhance",
            {
                method: "POST",
                body: formData
            }
        );

    const data =
        await response.json();

    document.getElementById(
        "processedEnhance"
    ).src = data.image;
}
